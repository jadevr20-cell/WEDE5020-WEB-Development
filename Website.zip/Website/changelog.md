All Green Foundation — Changelog

Version 2.0.0
- Added linked pages for the home page, about, garden, activities, gallery,
  produce, events, enquiry, contact, sitemap, and 404 page.
- Added shared external stylesheet with responsive desktop, tablet, and mobile
  layouts.
- Added navigation links between all pages.

Version 2.1.0
- Added image gallery paths for the six supplied pictures.
- Updated README with setup instructions, screenshot placeholders, and references.
- Added gallery to display images
- Added an Enquiry page to apply online
- Added new page: Activies for "Sustainable Gardening" , "Water Conservation" and also added a new "Workshops and Volunteering"

Version 2.2.0
- New Event Page for "Gardening Workshop" , "Water-Wise Gardening" , "Volunteer Garden Day"
- Email address has been added to contact page
- Sitemap has been revamped
- 404 Page has been revamp from "Oops! The page you're looking for doesn't exist" to "The page you are looking for could not be found"

Version 2.3.0
- Fixed error of pictures not showing
- Added new Produce page for more information about season harvesting
- Updated "Our Mission" and "Our Goals"
- Added a quick link at bottom for Sitemap and Contact, aswell as place a Contact page on top of the corner
- New Page has been added "Our Garden" for what you can explore.

Version 1.0.0
- Created the initial All Green Foundation website content.
- Added information about the foundation, community garden, activities, and
  contact details.
- Added section for "Sustainable Gardening" and "Water Conservation"

Version 1.1.0
- Reorganized list order for better logical flow: moved "Contact Us" closer to the bottom
- Created a basic 404 page with a centered "404" heading.
  Included a message: "Oops! The page you're looking for doesn't exist."
- Updated the mission statement to emphasize practical learning environments.
  Clarified the role of the garden.
