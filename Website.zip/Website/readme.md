# All Green Foundation

## Project information

**Student:** Jaden van Rooyen (ST10533345)  
**Module:** Web Development (WEDE5020W)  
**Assessment:** POE  
**Project type:** Community non-profit organisation website

The website introduces All Green Foundation and its work in sustainable
gardening, food production, environmental education, and community participation.

## Pages

- `index.html` — Home page.
- `about.html` — Foundation mission and goals.
- `garden.html` — Community garden information.
- `activities.html` — Projects, workshops, and gardening activities.
- `gallery.html` — Six supplied garden photographs.
- `menu.html` — Garden produce information.
- `promotions.html` — Events and workshops.
- `order.html` — Produce enquiry form example.
- `contact.html` — Contact information.
- `sitemap.html` — Links to all main pages.
- `404.html` — Page-not-found page.
- `style.css` — Shared responsive stylesheet.

## Setup

1. Keep the HTML files and `style.css` in the same project folder.
2. Put the six supplied images in a folder named `images`.
3. Confirm the image filenames and extensions match the HTML paths.
4. Open `index.html` in a browser. For local development, use a local server such
   as Visual Studio Code Live Server.
5. Test the pages and navigation links at desktop, tablet, and mobile sizes.

## Images

The gallery expects these files:

- `images/Picture 1.jpg`
- `images/Picture 2.jpg`
- `images/Picture 3.jpg`
- `images/Picture 4.jpg`
- `images/Picture 5.jpg`
- `images/Picture 6.jpg`

Update the image alt text and captions in `gallery.html` to accurately describe
the photographs.

## Responsive design 

The website uses a shared external stylesheet, CSS reset, typography, visual
styles, Grid, Flexbox, relative units, and media queries. The layout adapts for
desktop, tablet, and mobile screens.

Use browser developer tools to test the layout, navigation, and images at
different viewport sizes. Iterate on the design as needed.

## Screenshot evidence

Add screenshots you capture to a `screenshots` folder and update these paths:

- Desktop: `screenshots/desktop.png`
- Tablet: `screenshots/tablet.png`
- Mobile: `screenshots/mobile.png`

Include actual screenshots before submitting.

## GitHub

Repository URL: 

Commit changes with descriptive messages, push to the remote repository, and
submit the repository link through the Learning Management System.

## Changelog and references

See `changelog.md` for project changes.

References:

- MDN Web Docs, CSS media queries:
  https://developer.mozilla.org/docs/Web/CSS/CSS_media_queries/Using_media_queries
- MDN Web Docs, CSS Grid:
  https://developer.mozilla.org/docs/Web/CSS/CSS_grid_layout
- MDN Web Docs, Flexbox:
  https://developer.mozilla.org/docs/Web/CSS/CSS_flexible_box_layout
- MDN Web Docs, responsive images:
  https://developer.mozilla.org/docs/Web/HTML/Guides/Responsive_images
- Google Fonts: https://fonts.google.com/